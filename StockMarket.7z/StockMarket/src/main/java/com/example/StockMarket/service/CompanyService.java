package com.example.StockMarket.service;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarket.model.Company;




	
	public interface CompanyService extends CrudRepository<Company, Integer> {

		
	}



