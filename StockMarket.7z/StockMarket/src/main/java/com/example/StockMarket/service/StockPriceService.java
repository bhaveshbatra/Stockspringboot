package com.example.StockMarket.service;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarket.model.StockPrice;

public interface StockPriceService extends CrudRepository<StockPrice, Integer> {

	
}
