package com.example.StockMarket.service;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.example.StockMarket.model.User;




public interface LoginService extends JpaRepository<User, Integer>{

	

	User findByEmail(String email);

	Optional<User> findById(int id);
	

    @Query("Select c From User c where c.id = :id and c.confirmed = :confirmed")
	Optional<User> findIdAndCode(int id, String confirmed);

    @Query("Select c From User c where c.username = :username and c.password = :password")
	User findByUserNameAndPassword(String username, String password);

    @Query("Select c from User c where c.username= :username or c.email= :mail or c.mobilenumber=:contactnumber")
	Optional<User> findUser(String username, String mail, int contactnumber);





	




	
}
