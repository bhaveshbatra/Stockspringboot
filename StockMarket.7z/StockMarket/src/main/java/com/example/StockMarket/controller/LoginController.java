package com.example.StockMarket.controller;



import java.util.Optional;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarket.model.User;
import com.example.StockMarket.service.LoginService;



@Controller


public class LoginController {

	
	@Autowired
	LoginService userservice; 
	
	
	@RequestMapping(value = "/index")	
	public String getIndexpage()
	{
		 return "Home";
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	}
	
	@RequestMapping(value="/RegisterPage")
	public String getRegisterPage()
	{
		
		return "UserRegister";
	}

	@RequestMapping(value="/ForgotPassword")
	public String forgotPassword()
{
		return "forgotPassword";
}

	@RequestMapping(value="/ConfirmMail",method=RequestMethod.GET)
	public ModelAndView ConfirmMail(@RequestParam("E_Mail") String E_Mail)
	{
		 ModelAndView mv = new ModelAndView();
		 User userdata= new User();
	 userdata= userservice.findByEmail(E_Mail);
		System.out.println("Before Finding Out Side");
		if(userdata == null)	 
		 {
			 System.out.println("Email is incorrect");
			 mv.setViewName("ForgotPassword");
		 }
		
		else if(userdata.getEmail().contentEquals(E_Mail))
		{
			int RandomPin = (int)(Math.random()*9000)+1000;
			String otp= String.valueOf(RandomPin);
			System.out.println("OTP : "+otp);
			
			//User User = new User();
			//String Sent = UserController.send(E_Mail, "Verification code for Stock Exchange", message);
			String Sent = "Success";
			if(Sent.contentEquals("Success"))
			{
				System.out.println("OTP:Success");
				//User.setConfirmed(otp);
				//System.out.println("Before Finding"+userdata.getId());
				Optional<User> userdataObj= userservice.findById(userdata.getId());
				System.out.println(userdataObj.toString());
				if(userdataObj.isPresent())
				{
					User UserDataObj1= userdataObj.get();
					UserDataObj1.setConfirmed(otp);
					userservice.save(UserDataObj1);
					System.out.println("Please Check the mail");
					mv.setViewName("ConfirmationPage");
					mv.addObject("username", userdata.getUsername());
					mv.addObject("mail", userdata.getEmail());
					mv.addObject("UserId", userdata.getId());
				}
				else
				{
					mv.setViewName("ForgetPassword");
				}
			}
		
		}
		return mv;
		}
	
	@RequestMapping(value="/verifycode/{id}", method=RequestMethod.GET)
	public ModelAndView verifyUserCode(@PathVariable("id") int id, @RequestParam("code") String code, @RequestParam("username") String username, @RequestParam("mail") String mail)
	{
		 Optional<User> userdata =  userservice.findIdAndCode(id,code);
		 System.out.println("user data  :"+userdata.toString());
		 ModelAndView mv = new ModelAndView();
		 if(userdata.isPresent())
		 {
			 System.out.println("Verifying Code");
			    User UserdataObj1 = userdata.get();
				UserdataObj1.setUsertype("CU");
				userservice.save(UserdataObj1);
				System.out.println("Verified Successfully");
			    mv.setViewName("Home");
		 }
		 
		 else
		 {
			 System.out.println("Verification Code is wrong Please enter correct Code");
			 mv.setViewName("ConfirmationPage");
	         mv.addObject("username",username);
			 mv.addObject("mail",mail);
			 mv.addObject("UserId",id);
		 }
	return mv;
	
	}
	
	@RequestMapping(value="/confirmusercode/{id}",method=RequestMethod.GET)
	public ModelAndView confirmUserCode(@PathVariable("id") int id, @RequestParam("code") String code, @RequestParam("password") String password, @RequestParam("username")String username, @RequestParam("mail") String mail)
{
		 Optional<User> userdata =  userservice.findIdAndCode(id,code);
		 System.out.println("User data" +userdata.toString());
		 ModelAndView mv = new ModelAndView();
		 if(userdata.isPresent())
		 {
			 System.out.println("Changing password in database");
			    User UserdataObj1 = userdata.get();
				UserdataObj1.setPassword(password);
				userservice.save(UserdataObj1);
				System.out.println("password Changed Successfully");
			    mv.setViewName("Home");
		 }
		 else
		 {
			 System.out.println("Verification Code is wrong Please enter correct Code");
			 mv.setViewName("ConfirmationPage1");
	         mv.addObject("username",username);
			 mv.addObject("mail",mail);
			 mv.addObject("UserId",id);
		 }
		return mv;
}

@RequestMapping(value="/ValidateUser", method=RequestMethod.GET)
public ModelAndView validateUserInDB(@RequestParam("username") String username, @RequestParam("password")String password)
{
	
	System.out.println("Username :" + username);
	System.out.println("Password :" + password);
	User userdata = new User();
	userdata= userservice.findByUserNameAndPassword(username,password);
	
	ModelAndView mv = new ModelAndView();
	 System.out.println("After Checking");
	 
    if(userdata == null)
    {
    	mv.setViewName("Home");
    	System.out.println("Invalid Credentials");
    }
    else if(userdata.getUsertype().equals("Admin"))
    {
    	System.out.println("Usertype"+ userdata.getUsertype());
    	mv.setViewName("Home");
    }
    else if(userdata.getUsertype().equals("CUser"))
    {
    	System.out.println("User page");
    	mv.setViewName("Home");
    }
    else if(userdata.getUsertype().equals("Uuser"))
    {
    	System.out.println("Unconfirmed user login page");
    	mv.setViewName("Confirmation Page");
    	mv.addObject("username", username);
    	mv.addObject("mail", userdata.getEmail());
    	mv.addObject("UserId", userdata.getId());
    }
    else
    {
    	mv.setViewName("Home");
		System.out.println("Error While Authentication");
    }
	return mv;
	
}


}
