package com.example.StockMarket.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarket.model.User;
import com.example.StockMarket.service.LoginService;


@Controller
public class RegisterController {
	
	
	@Autowired
	LoginService userservice;
	
	@RequestMapping(value="/registeruser", method=RequestMethod.POST)
public ModelAndView signupUserDB(@RequestParam("username") String username, @RequestParam("password") String password, @RequestParam("email") String mail, @RequestParam("contact") String contact)
{		
		int contactnumber=Integer.parseInt(contact);
		
		Optional<User> userdata= userservice.findUser(username,mail,contactnumber);
		ModelAndView mv= new ModelAndView();
		if(userdata.isPresent())
		{
			if(userdata.get().getUsername().contentEquals(username))
			{
				System.out.println("username exists..");
			}
			if(userdata.get().getEmail().contentEquals(mail))
            {
            System.out.println("mail exists ");
            }
			 if(userdata.get().getMobilenumber() == contactnumber)
             {
             System.out.println("Contact number exists ");
             }
			 mv.setViewName("SignUpPage");
		}
		else
		{
			int randomPin = (int)(Math.random()*9000)+1000;
			String otp= String.valueOf(randomPin);
			System.out.println("OTP"+otp);
		       // String message = " Verification Code is : "+otp+"\n Happy Exploring!!"; 
            
            // String Sent = RegisterController.send("bhavesh.batra@feedingindia.org","Bhavesh12345",mail,"Verification code for Stock Exchange",message);
              String Sent = "Success";
              
              if(Sent.contentEquals("Success"))
              {
            	  int contact1=Integer.parseInt(contact);
            	  User userobj= new User(username,password,"UU",mail,contact1,otp);
            	  userservice.save(userobj);
            	  mv.setViewName("ConfiemationPage");
            	  mv.addObject("username", userobj.getUsername());
            	  mv.addObject("Id", userobj.getId());

              }
              
              else if(Sent.contentEquals("Failure"))
              {
            	  System.out.println("Error or Incorrect mail...");
            	  mv.setViewName("SignUpPage");
              }
			
		}
		
		return mv;
}






}
