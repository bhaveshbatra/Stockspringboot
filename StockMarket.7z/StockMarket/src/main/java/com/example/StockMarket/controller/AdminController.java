package com.example.StockMarket.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.sql.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.StockMarket.model.Company;
import com.example.StockMarket.model.StockPrice;
import com.example.StockMarket.service.CompanyService;
import com.example.StockMarket.service.StockPriceService;




@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockMarket")
public class AdminController {
	
	@Autowired
	CompanyService adminservice;
	
	@Autowired
	StockPriceService stockpriceservice;
	
	@GetMapping("/companies")
	public List<Company> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Company> customers = new ArrayList<>();
		adminservice.findAll().forEach(customers::add);

		return customers;

}
	@PostMapping(value="/companies/insert")
	public Company postCompany(@RequestBody Company company) {
		Company _company=adminservice.save(new Company(company.getCompanyName(),company.getTurnOver(),company.getCeo(),company.getBoardOfDirectors(), company.getSector(),company.getBrief(), company.getStockCode()));
		return _company;  
	}
	
	@DeleteMapping(value="/deletecompany/{companyCode}")
	public ResponseEntity<String> deleteCustomer(@PathVariable("companyCode") int companyCode)
	{
		System.out.println("Delete...");
		adminservice.deleteById(companyCode);
		return new ResponseEntity<>("Company has been deleted!", HttpStatus.OK);
		
	}
	
	@DeleteMapping("companies/delete")
	public ResponseEntity<String> deleteAllCompanies()
	{
		System.out.println("Delete all companies");
		adminservice.deleteAll();
		return new ResponseEntity<>("All companies deleted", HttpStatus.OK);
	}
	
	@PutMapping("/updatecompany/{companyCode}")
		public ResponseEntity<Company> updateConmpany(@PathVariable("companyCode") int companyCode, @RequestBody Company company)
		{
			System.out.println("Updation");
			Optional<Company> companyData = adminservice.findById(companyCode);
			
			if(companyData.isPresent())
			{
				Company _company=companyData.get();
				_company.setBoardOfDirectors(company.getBoardOfDirectors());
				_company.setBrief(company.getBrief());
				_company.setCeo(company.getCeo());
				_company.setCompanyCode(company.getCompanyCode());
				_company.setCompanyName(company.getCompanyName());
				_company.setSector(company.getSector());
				_company.setStockCode(company.getStockCode());
				_company.setTurnOver(company.getTurnOver());
				
				
				return new ResponseEntity<>(adminservice.save(_company), HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			
				
			
		}
	
	@RequestMapping(value="/uploadexcel")
	public String uploadExcel(@RequestParam("file") MultipartFile file1) throws IOException, ParseException
	{
		StockPrice sp= null;
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(file1.getInputStream());
        XSSFSheet sheet = workbook.getSheetAt(0); 
		Row row;
		int records=0;
		for(int i=1; i<=sheet.getLastRowNum(); i++)
		{
            row=(Row) sheet.getRow(i);
		
		String ids;
		if(row.getCell(0)==null) {
			ids="0";			
		}
		else 
			ids=row.getCell(0).toString();
		
		
		float id1=Float.parseFloat(ids), companyid1, stockid1;
		
		String companyids;
		if(row.getCell(1)==null)
		{
			companyids="0";
		}
		else 
			companyids=row.getCell(1).toString();
		
		companyid1=Float.parseFloat(companyids);
		
		
		String stockids;
		if(row.getCell(2)==null) {stockids="0";}
		
		
		else stockids= row.getCell(2).toString();
		
		stockid1=Float.parseFloat(stockids);
		int id=(int)id1, companyid=(int)companyid1, stockid=(int)stockid1;
		
		String currentPriceS;
        if( row.getCell(3)==null) { currentPriceS = "0";}  
        else currentPriceS = row.getCell(3).toString();   
        
        float currentPrice = Float.parseFloat(currentPriceS);
        
        
        
        String dateinexcelS;
       if( row.getCell(4)==null) { dateinexcelS = "null";   }
       else  dateinexcelS   = row.getCell(4).toString();
       
          
           Date dateinexcel=new SimpleDateFormat("dd/MM/yyyy").parse(dateinexcelS); 
           
           
           String timeinexcelS;
           if( row.getCell(5)==null) { timeinexcelS = "null";   }
           else  timeinexcelS   = row.getCell(5).toString();
           
           
           DateFormat sdf = new SimpleDateFormat("hh:mm:ss");
           Date timeinexcel = sdf.parse(timeinexcelS);

           
           System.out.println("Id :"+id+"companyid :"+companyid+"     stockexchangeid :"+stockid+
                   "    currentPrice :"+currentPrice+"    dateinexcel :"+dateinexcel+
                   "    timeinexcel :"+timeinexcel);
         sp = new StockPrice(companyid,stockid,currentPrice,dateinexcel,timeinexcel);

          records++;
          stockpriceservice.save(sp);
          sp = null;

		}
		return null;
		
	}
	
	}
	
